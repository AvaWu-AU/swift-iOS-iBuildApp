//
//  ExhibitorDetailModelTest.swift
//  iBuildApp
//
//  Created by WUQINGHUA on 5/02/2017.
//  Copyright © 2017 Ava Wu. All rights reserved.
//

import XCTest
@testable import iBuildApp

class ExhibitorDetailModelTest: XCTestCase {

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }

    func testInit_ShouldHoldImageName(){

        let exhibitorDetailModel = ExhibitorDetailModel(imagesName: ["Product1","Product2","Product3","Product4"])

        XCTAssertEqual(exhibitorDetailModel.imagesName,["Product1","Product2","Product3","Product4"])


    }

}
