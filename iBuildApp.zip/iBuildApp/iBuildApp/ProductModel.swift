//
//  ProductModel.swift
//  iBuildApp
//
//  Created by WUQINGHUA on 4/02/2017.
//  Copyright © 2017 Ava Wu. All rights reserved.
//

import Foundation

struct ProductModel{

    let logoImageName: String
    //"iBuildLogo"
    var productName = [String]()
    //["Product1","Product2","Product3","Product4"]


}
