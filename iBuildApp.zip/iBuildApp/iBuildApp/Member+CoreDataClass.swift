//
//  Member+CoreDataClass.swift
//  iBuildApp
//
//  Created by WUQINGHUA on 27/01/2017.
//  Copyright © 2017 Ava Wu. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData

@objc(Member)
public class Member: NSManagedObject {

}
