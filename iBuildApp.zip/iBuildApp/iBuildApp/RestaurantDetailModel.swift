//
//  RestaurantDetailModel.swift
//  iBuildApp
//
//  Created by WUQINGHUA on 4/02/2017.
//  Copyright © 2017 Ava Wu. All rights reserved.
//

import Foundation

class RestaurantDetailModel{

    var mainRestaurantName: String = ""

   /* init(mainRestaruantName:String) {

        self.mainRestaurantName = mainRestaurantName

    }
*/
}
