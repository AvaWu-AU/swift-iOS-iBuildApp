//
//  ExhibitorTableViewCell.swift
//  iBuildApp
//
//  Created by WUQINGHUA on 20/01/2017.
//  Copyright © 2017 Ava Wu. All rights reserved.
//

import UIKit

class ExhibitorTableViewCell: UITableViewCell {

    @IBOutlet weak var mainImageView: UIImageView!

    @IBOutlet weak var mainLable1: UILabel!

    @IBOutlet weak var mainLable2: UILabel!

    }
